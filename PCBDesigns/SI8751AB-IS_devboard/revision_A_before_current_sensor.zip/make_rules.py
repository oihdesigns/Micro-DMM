from pathlib import Path
ROOT=Path(__file__).resolve().parent
def names(item,nn):return '('+' || '.join(f"{item}.NetName == '/{n}'" for n in nn)+')'
hi=['RAIL_IN','RAIL_OUT','SOURCE_FLOAT','GATE_1','GATE_2','MCAP_1','MCAP_2','DIV_1','DIV_2']
flo=['SOURCE_FLOAT','GATE_1','GATE_2','MCAP_1','MCAP_2']
logic=['+3V3','GND_LOGIC','EN','EN_A','EN_B','TT_1','TT_2','VOUT_ADC']
field=hi+['GND_LOAD_RETURN','ISO_3V3','ISO_5V_RAW','SENSE_IN']
rules=['(version 1)']
def rule(title,cond,value):rules.append(f'(rule "{title}" (condition "{cond}") (constraint clearance (min {value}mm)))')
rule('Field voltage nodes',names('A',hi)+' || '+names('B',hi),.8)
rule('Low voltage floating gate domain',names('A',flo)+' && '+names('B',flo),.3)
cross='(('+names('A',logic)+' && '+names('B',field)+') || ('+names('B',logic)+' && '+names('A',field)+'))'
rule('Control to live field copper',cross,2.5)
# Converter is the intentional limiting barrier. Its pad separation is 1.14mm.
# The local rule permits its documented geometry, without declaring safety isolation.
rule('Converter pin escape - functional isolation only',cross+" && (A.intersectsCourtyard('U3') || B.intersectsCourtyard('U3'))",.8)
# Unconnected pins still need normal fabrication spacing; no signal is applied.
rule('Unused pins',"A.NetName == 'unconnected-*' || B.NetName == 'unconnected-*'",.25)
(ROOT/'SI8751AB-IS_devboard.kicad_dru').write_text('\n'.join(rules)+'\n')
