# Si8751 AC/DC switch development board, revision A

Editable KiCad 10 project for a **120 V RMS AC / 170 V DC, less than 1 A bench prototype**. It uses two SI8751AB-IS drivers, two STP12N60M2 MOSFETs, one SCT01F03S05 converter, and one AMC0330RDWVR voltage amplifier. All resistors and capacitors are **0805**. The PCB is two layers, 110 x 90 mm, intended for 1.6 mm FR-4 and 35 um copper.

Open `SI8751AB-IS_devboard.kicad_pro`. Symbols and footprints are included in project-local libraries; no online library installation is necessary. The PDF is an exported schematic. `BOM.csv` is the component list, `fabrication/` contains prototype fabrication outputs, and `validation/` contains the checks and previews.

## Operating scope

The specified voltage/current are **design targets, not measured or certified ratings**. Start with resistive loads and at most one complete on/off cycle per second. This is not a high-frequency PWM driver. Inrush, inductive interruption, fault clearing, EMI and high-temperature operation have not been validated. No MOV, snubber or onboard fuse is fitted; use an external fuse rated for the source voltage, AC/DC type and prospective fault current, at no more than 1 A. Capacitive or inductive loads need a separate transient and safe-operating-area assessment.

The complete board provides functional isolation only. The converter is the limiting component: its 1 kV DC isolation test specification does not establish reinforced mains insulation. Its adjacent primary/secondary pads are only 1.14 mm apart through air. A 0.6 x 10 mm milled slot increases board-surface creepage, but does not increase that air gap or certify the internal converter insulation. Treat the controller interface accordingly and use an appropriately isolated, current-limited bench source. A design for direct unattended mains service requires a different power-isolation solution and equipment-level insulation review. [XP Power SCT01F datasheet](https://www.xppower.com/storage/portals/0/pdfs/SF_SCT01F.pdf).

## Connections

| Connector / pin | Function |
|---|---|
| J1-1 | Regulated +3.3 V input; supply capable of at least 100 mA is recommended |
| J1-2 | Logic ground |
| J1-3 | EN: 3.3 V logic HIGH turns both MOSFETs on; LOW turns both off |
| J1-4 | Single-ended voltage output to an external ADC |
| J1-5 | Logic ground, convenient ADC return |
| J2-1 | Source line / positive DC rail |
| J2-2 | Source return |
| J3-1 | Switched output line |
| J3-2 | Load return, directly connected to J2-2 |

J2/J3 are 7.62 mm pluggable headers **691311400102**. Order **two 691351400002 cable plugs** separately. The manufacturer lists the Series 3514 plug as mating with the Series 3114 header. [Wuerth mating connector details](https://www.we-online.com/en/components/products/TBL_7_62_3514_VERTICAL_69135140000X).

The host ADC must use the same +3.3 V reference as J1-1, or use its actual reference ratio in the conversion. Do not feed J1 with 5 V: the converter input is a 3.3 V supply. Keep the ADC connection short and within the AMC output load limits; any ADC input filter or buffer belongs in the host interface.

## Switching circuit

```text
J2-1 -- D(Q1) S -- SOURCE_FLOAT -- S(Q2) D -- J3-1
              G1                            G2
              |                             |
        Si8751 U1 GATE                 Si8751 U2 GATE
        U1 SOURCE -------------------- U2 SOURCE
                          |
                    SOURCE_FLOAT

J2-2 ---------------- GND_LOAD_RETURN ---------------- J3-2
```

The opposing body diodes block either polarity when both gates are off. Each driver has its own gate connection; the outputs are not tied together. `SOURCE_FLOAT` is a separate domain from both logic ground and load return. Both inputs share EN through individual 100 ohm resistors and default-low 100 kohm resistors.

Each driver uses a 10 kohm TT resistor and a 10 pF, 1 kV C0G drain-to-MCAP1 capacitor. MCAP2 is intentionally unused. A conventional low-value gate/source bleed resistor is omitted because it would load the generated gate voltage. The drivers transfer their own gate energy across isolation; the DC/DC converter powers only measurement. [Skyworks Si8751/52 datasheet](https://www.skyworksinc.com/-/media/SkyWorks/SL/documents/public/data-sheets/Si8751-2.pdf).

Q1/Q2 are 600 V STP12N60M2, TO-220, with pins 1=gate, 2=drain, 3=source. Their tabs are live drains at different potentials: do not bolt both directly to one conductive heatsink. At 1 A and 0.45 ohm per device the estimated combined conduction loss is 0.9 W. That estimate uses the MOSFET's 10 V gate specification. The Si8751 has a weaker, load-dependent gate supply, so actual VGS, voltage drop, transition time and temperature must be measured. It is not a guaranteed loss calculation for every temperature and device corner. [ST MOSFET product and datasheet](https://www.st.com/en/power-transistors/stp12n60m2.html).

## Voltage measurement and scaling

The converter's secondary return is tied to J3-2. U4, TPS70933DBVR, regulates its unregulated output to 3.3 V for the isolated side of the amplifier. U4 EN is intentionally left floating as permitted by its datasheet; it must not be tied to an unbounded raw converter output. C8 must retain at least 2.2 uF effective capacitance at 3.3 V. [TI TPS709 datasheet](https://www.ti.com/lit/ds/symlink/tps709.pdf).

R10-R12 = 390 kohm each; R13 = 4.99 kohm. Use 0.1%, 25 ppm/K or better parts, with at least 150 V continuous working rating and 0.125 W rating for each top resistor. C14 = 100 pF C0G. The divider bottom and SNSN connect to the load-return sense node.

| Calculated quantity | Value |
|---|---:|
| Divider ratio, (1,170,000 + 4,990) / 4,990 | 235.468938 |
| Sense input at 120 V RMS sine | 0.72071 V peak |
| Sense input at 132 V RMS, allowance for +10% line | 0.79278 V peak |
| Sense input at 170 V DC | 0.72196 V |
| Divider current at 120 V RMS | 102.13 uA RMS |
| Dissipation in each 390 kohm resistor at 132 V RMS | 4.92 mW |
| Approximate divider/C14 pole | 320 kHz |

For instantaneous rail voltage, the nominal conversion is:

```text
Vrail = 235.468938 * 1.28 * (2 * Vout / Vref - 1)
      = 602.800481 * (Vout / Vref - 0.5)
```

The factor **1.28** is the AMC0330R nominal clipping input, not its ±1 V specified linear range. At Vref=3.3 V, zero input gives 1.65 V, and 120 V RMS produces approximately 1.65 V ±0.929 V. Calibrate zero and gain against a known input. For AC RMS, convert each sample to instantaneous rail volts, square, average over whole cycles, then take the square root. RMS after subtracting the mean gives AC-only RMS; omitting mean subtraction includes any DC component.

Loss of isolated amplifier power also produces a midscale output. A midscale reading alone therefore cannot establish that the rail is off. The amplifier is specified for ±1 V input; its larger nominal clipping point must not be used as the precision measurement limit. [TI AMC0330R datasheet](https://www.ti.com/lit/ds/symlink/amc0330r.pdf).

## Layout and assembly

- Primary load-current routes are 1.0 mm; gate/sense/control branches are 0.3 mm. There are no copper pours crossing isolation.
- Field voltage nodes use 0.8 mm clearance. The low-voltage floating gate domain uses 0.3 mm. Logic-to-field routing uses 2.5 mm, with a documented local functional-isolation exception at U3.
- The TO-220 pad width is narrowed to 1.65 mm while retaining the original 1.1 mm drill, providing 0.89 mm adjacent copper clearance. This is an intentional project-local footprint change.
- All plated component pads have openings on both solder-mask layers. The U3 slot needs a fabricator capable of 0.6 mm routing; its nearest pad copper is 0.27 mm away. Confirm routing and registration tolerances before fabrication.
- Use 0805 X7R supply capacitors, with the voltage ratings listed in the BOM and DC-bias capacitance checked. C3/C4 must be 1 kV C0G, not ordinary 50 V capacitors. A candidate is KEMET C0805C100JDGACTU; verify current orderable specifications before purchase.
- Four 3.2 mm mounting holes are included. Use insulating standoffs. Connector housings and the two separate MOSFET tabs need clearance from any enclosure.

## Initial bench validation

1. With no switched source connected, inspect assembly and check there is no conductive bridge between logic ground, SOURCE_FLOAT and GND_LOAD_RETURN.
2. Apply 3.3 V with a current limit. Verify U3 raw output is within C7/U4 limits, U4 output is approximately 3.3 V, and J1-4 is near half the reference with zero sensed voltage. Sweep the allowed 3.0-3.6 V converter input range during qualification.
3. Use a low-voltage, current-limited DC source and resistive load. Confirm EN-low blocks both applied polarities and EN-high conducts both. Repeat after removing logic power. Inspect each gate relative to its own source with an appropriate isolated differential probe; a 10 Mohm or higher input resistance minimizes gate loading.
4. Measure actual gate voltage, turn-on/off time and drain overshoot. Do not assume the Si8751 timing figures measured with a small capacitive load apply to these MOSFETs. The 10 pF MCAP capacitors imply a 600 V/us upper slew-rate check at the 6 mA MCAP current limit.
5. Calibrate voltage sensing at zero and known positive/negative voltages. Verify AC scaling with a known waveform before raising the voltage. Use properly rated probes; do not connect an earth-grounded scope clip to the floating source or field return.
6. Increase voltage/current gradually within the target envelope using the isolated bench setup. Log VGS, conduction loss, turn-off behavior and MOSFET case temperature after thermal equilibrium at the intended ambient. Increase the switching rate only after checking switching loss and SOA.

No hardware has been built or tested as part of this design delivery. KiCad checks establish file/connectivity/geometry consistency, not functional or insulation qualification.

## Rebuilding

Run `build_design.py`, `make_rules.py`, and `build_pcb.py` with the Python bundled in KiCad 10. These scripts regenerate the design and overwrite manual edits. The circuit JSON is an intermediate output. Re-run `kicad-cli sch erc` and `kicad-cli pcb drc --schematic-parity` after changes. Preserve the project-local libraries and `.kicad_dru` file when sharing the project.
