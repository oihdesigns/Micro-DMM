"""Build and route the PCB using KiCad's bundled Python / pcbnew.

Creates a two-layer PCB, retaining schematic UUIDs for update/parity checks.
"""
from pathlib import Path
import json, math, heapq, itertools, os
import numpy as np
import pcbnew as k
from design import ROOT, NAME, SHEET, uid

os.environ['KICAD_CONFIG_HOME']=str(ROOT/'tmp/kicad-config')
parts=json.loads((ROOT/'scripts/components.json').read_text())
b=k.BOARD()
mm=k.FromMM
def pos(x,y):return k.VECTOR2I(mm(float(x)),mm(float(y)))
netnames=sorted({v for p in parts for v in p['nets'].values()})
nets={}
for name in netnames:
    n=k.NETINFO_ITEM(b,name);b.Add(n);nets[name]=n
fps={};pads={}
for p in parts:
    f=k.FootprintLoad(str(ROOT/'AD8237DevBoard.pretty'),p['fp'].split(':')[1])
    f.SetReference(p['ref']);f.SetValue(p['value'])
    f.SetFPID(k.LIB_ID('AD8237DevBoard',p['fp'].split(':')[1]))
    path=k.KIID_PATH();path.push_back(k.KIID(SHEET));path.push_back(k.KIID(p['uuid']));f.SetPath(path)
    f.SetSheetfile(NAME+'.kicad_sch');f.SetSheetname('')
    f.SetField('Assembly',p['notes'])
    f.GetField('Assembly').SetVisible(False)
    if p['kind']=='AD8237':f.SetField('Datasheet','https://www.analog.com/media/en/technical-documentation/data-sheets/ad8237.pdf')
    if p['kind']=='AD8237':f.GetField('Datasheet').SetVisible(False)
    f.SetAttributes(f.GetAttributes() & ~k.FP_EXCLUDE_FROM_BOM)
    if p['dnp']:f.SetAttributes(f.GetAttributes() | k.FP_DNP)
    x,y,a=p['pcb'];f.SetPosition(pos(x,y));f.SetOrientationDegrees(a)
    f.Reference().SetTextSize(pos(.8,.8));f.Reference().SetTextThickness(mm(.12))
    f.Reference().SetTextAngle(k.EDA_ANGLE(0,k.DEGREES_T));f.Reference().SetPosition(pos(x,y-1.65))
    f.Value().SetVisible(False)
    if p['ref'].startswith(('H','TP','JP','J')):f.Reference().SetVisible(False)
    if p['ref']=='U1':f.Reference().SetPosition(pos(x,y-2.5))
    if p['ref']=='C3':f.Reference().SetPosition(pos(x-2,y))
    for pad in f.Pads():
        number=pad.GetNumber()
        if number in p['nets']:pad.SetNet(nets[p['nets'][number]])
        pads[p['ref'],number]=pad
    b.Add(f);fps[p['ref']]=f

def line(a,c,layer=k.Edge_Cuts,width=.05):
    s=k.PCB_SHAPE();s.SetShape(k.SHAPE_T_SEGMENT);s.SetStart(pos(*a));s.SetEnd(pos(*c));s.SetLayer(layer);s.SetWidth(mm(width));b.Add(s)
for a,c in [((100,100),(150,100)),((150,100),(150,140)),((150,140),(100,140)),((100,140),(100,100))]:line(a,c)
def txt(t,x,y,size=1,layer=k.F_SilkS):
    v=k.PCB_TEXT(b);v.SetText(t);v.SetPosition(pos(x,y));v.SetTextSize(pos(size,size));v.SetTextThickness(mm(.15 if size>=1 else .12));v.SetLayer(layer)
    if layer==k.B_SilkS:v.SetMirrored(True)
    b.Add(v)
txt('AD8237',125,102.5,1.5);txt('SENSOR DEV  Rev A',128,104.5,1)
txt('3V3 / 5V',110,103.5,.8)
txt('V+',110,108,.8);txt('GND',112.6,108,.8)
txt('J2',103,113,.8)
for y,t in [(116,'IN+'),(118.54,'IN-'),(121.08,'GND')]:txt(t,102,y,.8)
txt('BW',120.54,110.3,.8);txt('L',118,105.8,.8);txt('H',123.08,105.8,.8)
txt('GAIN',140.2,112.5,1)
for y,t in [(115.5,'1'),(118.04,'10'),(120.58,'101')]:txt(t,144.5,y,.8)
txt('1 SHUNT',140,110.8,.8)
for y,t in [(123,'OUT'),(125.54,'GND'),(128.08,'REF')]:txt(t,148.8,y,.8)
txt('REF SELECT',139,136,.8);txt('GND',133,133,.8);txt('EXT',144,133,.8)
txt('3.3 V nominal / 5 V compatible',124.5,136.7,.85)
for t,x,y in [('V+',107,112),('GND',107,132.2),('+IN',120,123.3),('-IN',120,132.2),('RAW',134,106.2),('FB',132.5,121),('REF',128,134.2)]:txt(t,x,y,.8)
txt('AD8237  |  Micro-DMM',125,111,1.2,k.B_SilkS)
txt('SUPPLY 1.8-5.5 V\nJP1: 1 / 10.09 / 101\nFit one gain shunt\nHIGH BW: gain >= 10\nREF: ground or external\nC3-C6, R9-R10: DNP',125,121,1,k.B_SilkS)
txt('Prototype Rev A  2026-09',125,132,1,k.B_SilkS)

def track(net,a,c,layer=k.F_Cu,width=.2):
    if a==c:return
    t=k.PCB_TRACK(b);t.SetStart(pos(*a));t.SetEnd(pos(*c));t.SetWidth(mm(width));t.SetLayer(layer);t.SetNet(nets[net]);b.Add(t)
def via(net,x,y):
    v=k.PCB_VIA(b);v.SetPosition(pos(x,y));v.SetWidth(mm(.6));v.SetDrill(mm(.3));v.SetLayerPair(k.F_Cu,k.B_Cu);v.SetNet(nets[net]);b.Add(v)
def padxy(ref,num):
    p=pads[ref,str(num)].GetPosition();return k.ToMM(p.x),k.ToMM(p.y)

# Short, deliberate analog connections at the IC.
def manual(net,points,width=.2):
    for a,c in zip(points,points[1:]):track(net,a,c,width=width)
manual('IN_P_F',[padxy('R1',2),(118.25,116.8),(120.125,118.675),padxy('U1',2)])
manual('IN_N_F',[padxy('R2',2),(118.25,121.2),(120.125,119.325),padxy('U1',3)])
manual('VS',[padxy('U1',5),(126.95,119.975),(126.95,121.5),(125.05,121.5),padxy('C2',1)],.25)
manual('GND',[padxy('U1',4),(120.8875,121.5)])
via('GND',120.8875,121.5)
pads['U1','4'].SetLocalZoneConnection(k.ZONE_CONNECTION_FULL)
manual('GND',[padxy('C2',2),(127.8,123)],.3);via('GND',127.8,123)

# Grid router. Explicit pad/track/via obstacles include clearance plus a margin.
# Ground is connected through the plane; through-hole pads provide layer access.
STEP=.1;NX=501;NY=401;CLEAR=.21;W=.2
def grid(x,y):return int(round((x-100)/STEP)),int(round((y-100)/STEP))
def world(x,y):return round(100+x*STEP,4),round(100+y*STEP,4)
def layers(pad):return [0,1] if pad.GetAttribute()==k.PAD_ATTRIB_PTH else [0]
def circle(mask,x,y,r,ls):
    ix,iy=grid(x,y);ir=math.ceil(r/STEP)+1
    xa=max(0,ix-ir);xb=min(NX,ix+ir+1);ya=max(0,iy-ir);yb=min(NY,iy+ir+1)
    xx=100+np.arange(xa,xb)*STEP;yy=100+np.arange(ya,yb)*STEP
    sel=(xx[:,None]-x)**2+(yy[None,:]-y)**2 <=r*r
    for l in ls:mask[l,xa:xb,ya:yb] |= sel
def rect(mask,x,y,sx,sy,margin,ls):
    xa=max(0,math.ceil((x-sx/2-margin-100)/STEP));xb=min(NX,math.floor((x+sx/2+margin-100)/STEP)+1)
    ya=max(0,math.ceil((y-sy/2-margin-100)/STEP));yb=min(NY,math.floor((y+sy/2+margin-100)/STEP)+1)
    for l in ls:mask[l,xa:xb,ya:yb]=True
def obstacles(net,radius=.1):
    mask=np.zeros((2,NX,NY),dtype=bool)
    edge=math.ceil((.3+radius)/STEP)
    mask[:,:edge,:]=True;mask[:,-edge:,:]=True;mask[:,:,:edge]=True;mask[:,:,-edge:]=True
    for f in b.GetFootprints():
        for p in f.Pads():
            if p.GetNetname()==net:continue
            xy=p.GetPosition();sz=p.GetSize();x,y=k.ToMM(xy.x),k.ToMM(xy.y);sx,sy=k.ToMM(sz.x),k.ToMM(sz.y)
            a=p.GetOrientationDegrees()%180
            if abs(a-90)<1:sx,sy=sy,sx
            ls=layers(p)
            if p.GetAttribute()==k.PAD_ATTRIB_NPTH:ls=[0,1]
            if p.GetShape()==k.PAD_SHAPE_CIRCLE:circle(mask,x,y,sx/2+CLEAR+radius,ls)
            else:rect(mask,x,y,sx,sy,CLEAR+radius,ls)
    for t in b.GetTracks():
        if t.GetNetname()==net:continue
        a=t.GetStart();c=t.GetEnd();x,y=k.ToMM(a.x),k.ToMM(a.y);xx,yy=k.ToMM(c.x),k.ToMM(c.y)
        ls=[0,1] if isinstance(t,k.PCB_VIA) else [0 if t.GetLayer()==k.F_Cu else 1]
        rr=k.ToMM(t.GetWidth(k.F_Cu) if isinstance(t,k.PCB_VIA) else t.GetWidth())/2+CLEAR+radius
        dist=math.hypot(xx-x,yy-y);steps=max(1,math.ceil(dist/(STEP*.65)))
        for j in range(steps+1):circle(mask,x+(xx-x)*j/steps,y+(yy-y)*j/steps,rr,ls)
    return mask

def findpath(net,start,goals):
    blocked=obstacles(net);vblock=obstacles(net,.3)
    goalset=set(goals)
    def heuristic(s):
        x,y,l=s;return min(max(abs(x-a),abs(y-c))+.41421356*min(abs(x-a),abs(y-c))+(0 if l==ll else 10) for a,c,ll in goals)
    pq=[];dist={};prev={};counter=itertools.count()
    for s in start:dist[s]=0;heapq.heappush(pq,(heuristic(s),next(counter),s))
    moves=[(1,0,1),(-1,0,1),(0,1,1),(0,-1,1),(1,1,1.41421356),(-1,1,1.41421356),(1,-1,1.41421356),(-1,-1,1.41421356)]
    count=0
    while pq:
        _,_,s=heapq.heappop(pq);x,y,l=s;cost=dist[s];count+=1
        if s in goalset:
            result=[s]
            while s in prev:s=prev[s];result.append(s)
            return result[::-1]
        if count>450000:break
        for dx,dy,dc in moves:
            xx,yy=x+dx,y+dy
            if not(0<=xx<NX and 0<=yy<NY) or blocked[l,xx,yy]:continue
            if dx and dy and (blocked[l,x+dx,y] or blocked[l,x,y+dy]):continue
            n=(xx,yy,l);nc=cost+dc*(1.025 if l else 1)
            if nc<dist.get(n,1e30):dist[n]=nc;prev[n]=s;heapq.heappush(pq,(nc+heuristic(n),next(counter),n))
        if not vblock[0,x,y] and not vblock[1,x,y]:
            n=(x,y,1-l);nc=cost+24
            if nc<dist.get(n,1e30):dist[n]=nc;prev[n]=s;heapq.heappush(pq,(nc+heuristic(n),next(counter),n))
    raise RuntimeError(f'Cannot route {net}: {start} -> {goals}; explored {count}')

def pathdraw(net,path):
    if len(path)<2:return
    # Keep only corners and layer transitions.
    simple=[path[0]]
    for j in range(1,len(path)-1):
        d1=tuple(path[j][v]-path[j-1][v] for v in range(3));d2=tuple(path[j+1][v]-path[j][v] for v in range(3))
        if d1!=d2:simple.append(path[j])
    simple.append(path[-1])
    for (x,y,l),(xx,yy,ll) in zip(simple,simple[1:]):
        if l!=ll:via(net,*world(x,y))
        else:track(net,world(x,y),world(xx,yy),k.F_Cu if l==0 else k.B_Cu)

# Each net is routed as a nearest-neighbour tree; all physical pads, including
# optional components and probe pads, are in the routing graph.
order=['FB','OUT_RAW','GAIN10','GAIN101','IN_P_F','IN_N_F','IN_P','IN_N','VS','BW','REF','REF_EXT','OUT']
for net in order:
    ps=[p for p in pads.values() if p.GetNetname()==net]
    connected=[ps.pop(0)]
    while ps:
        pairs=[(math.hypot(k.ToMM(p.GetPosition().x-q.GetPosition().x),k.ToMM(p.GetPosition().y-q.GetPosition().y)),i,q) for i,p in enumerate(ps) for q in connected]
        _,i,q=min(pairs,key=lambda z:z[0]);p=ps.pop(i)
        a=p.GetPosition();c=q.GetPosition();aa=grid(k.ToMM(a.x),k.ToMM(a.y));cc=grid(k.ToMM(c.x),k.ToMM(c.y))
        start=[(*aa,l) for l in layers(p)];goals=[(*cc,l) for l in layers(q)]
        path=findpath(net,start,goals);pathdraw(net,path)
        # Join snapped grid coordinates to the true pad centers, inside each pad.
        track(net,(k.ToMM(a.x),k.ToMM(a.y)),world(*aa),k.F_Cu if path[0][2]==0 else k.B_Cu)
        track(net,(k.ToMM(c.x),k.ToMM(c.y)),world(*cc),k.F_Cu if path[-1][2]==0 else k.B_Cu)
        connected.append(p)
    print('Routed',net,flush=True)

# Local ground vias at SMD ground pads, with top copper to connect to the plane.
for ref,num in [('C1',2),('C4',2),('C5',2),('C6',2),('R7',2)]:
    x,y=padxy(ref,num)
    # Find a nearby clear ground via location and route the short connection.
    vblock=obstacles('GND',.3);found=False
    for radius in [.8,1,1.3,1.6,2,2.5]:
        for dx,dy in [(1,0),(0,1),(0,-1),(-1,0),(1,1),(-1,1),(1,-1),(-1,-1)]:
            gx,gy=grid(x+dx*radius,y+dy*radius)
            if not(0<gx<NX and 0<gy<NY) or vblock[0,gx,gy] or vblock[1,gx,gy]:continue
            path=findpath('GND',[(*grid(x,y),0)],[(gx,gy,0)]);pathdraw('GND',path);via('GND',*world(gx,gy));found=True;break
        if found:break
    if not found:raise RuntimeError('No ground via '+ref)

for x,y in [(106,105),(106,135),(144,105),(144,135),(105,126),(145,110),(125,135)]:
    bx,by=grid(x,y);vb=obstacles('GND',.3)
    if not vb[0,bx,by] and not vb[1,bx,by]:via('GND',x,y)

for layer in [k.F_Cu,k.B_Cu]:
    z=k.ZONE(b);z.SetLayer(layer);z.SetNet(nets['GND']);z.SetLocalClearance(mm(.2));z.SetThermalReliefGap(mm(.25));z.SetThermalReliefSpokeWidth(mm(.3));z.SetPadConnection(k.ZONE_CONNECTION_THERMAL);z.SetMinThickness(mm(.2));z.SetIslandRemovalMode(k.ISLAND_REMOVAL_MODE_ALWAYS)
    poly=z.Outline();poly.NewOutline()
    for x,y in [(100.5,100.5),(149.5,100.5),(149.5,139.5),(100.5,139.5)]:poly.Append(mm(x),mm(y))
    b.Add(z)
b.BuildConnectivity()
for name,n in nets.items():n.SetNetname('/'+name)
k.SaveBoard(str(ROOT/(NAME+'.kicad_pcb')),b)
print('Saved board; run kicad-cli pcb drc --refill-zones --save-board for final filling')
