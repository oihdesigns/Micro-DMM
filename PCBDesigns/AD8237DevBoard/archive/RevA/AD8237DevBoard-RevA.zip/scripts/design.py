"""Generate the editable AD8237 dev-board schematic, local libraries and BOM.

Run with Python 3. This file is the component/net source for build_pcb.py.
"""
from pathlib import Path
import json, uuid, csv, shutil

ROOT = Path(__file__).resolve().parents[1]
NAME = 'AD8237DevBoard'
NS = uuid.UUID('89d69edb-af28-46c2-b4c0-fb6a3720d6bc')
def uid(s): return str(uuid.uuid5(NS, s))
SHEET = uid('sheet')
KICAD = Path('C:/Program Files/KiCad/10.0/share/kicad')
RFP='Resistor_SMD:R_0805_2012Metric'
CFP='Capacitor_SMD:C_0805_2012Metric'
H2='Connector_PinHeader_2.54mm:PinHeader_1x02_P2.54mm_Vertical'
H3='Connector_PinHeader_2.54mm:PinHeader_1x03_P2.54mm_Vertical'
H6='Connector_PinHeader_2.54mm:PinHeader_2x03_P2.54mm_Vertical'
TP='TestPoint:TestPoint_Pad_D1.5mm'
HOLE='MountingHole:MountingHole_3.2mm_M3'
parts=[]
def add(ref,value,kind,fp,nets,sch,pcb,dnp=False,notes=''):
    parts.append(dict(ref=ref,value=value,kind=kind,source_fp=fp,fp='AD8237DevBoard:'+fp.split(':')[1],nets={str(k):v for k,v in enumerate(nets,1)},sch=sch,pcb=pcb,dnp=dnp,notes=notes,uuid=uid(ref)))

add('U1','AD8237ARMZ','AD8237','Package_SO:MSOP-8_3x3mm_P0.65mm',
    ['BW','IN_P_F','IN_N_F','GND','VS','REF','FB','OUT_RAW'],[139.7,83.82,0],[123,119,0],notes='Analog Devices AD8237ARMZ; MSOP-8, RM-8')
add('J1','POWER','Conn2',H2,['VS','GND'],[35.56,38.1,0],[110,106,90],notes='2.54 mm male header; regulated 3.3 V nominal, 5 V supported')
add('J2','SENSOR','Conn3',H3,['IN_P','IN_N','GND'],[35.56,81.28,0],[105,116,0],notes='Pin 1 IN+, 2 IN-, 3 GND')
add('J3','OUT / EXT REF','Conn3',H3,['OUT','GND','REF_EXT'],[254,81.28,0],[146,123,0],notes='Pin 1 OUT, 2 GND, 3 EXT REF')
add('JP1','GAIN: ONE SHUNT','Gain',H6,['FB','OUT_RAW','FB','GAIN10','FB','GAIN101'],[246.38,120.65,0],[139,115.5,0],notes='Fit ONE 2.54 mm shunt on pins 3-4 (G=10.09); 1-2: unity; 5-6: 101')
add('JP2','BW: LB / HB','Conn3',H3,['GND','BW','VS'],[152.4,38.1,0],[118,108,90],notes='Fit shunt 1-2 for low bandwidth; 2-3 high bandwidth, G>=10 only')
add('JP3','REF: GND / EXT','Conn3',H3,['GND','REF','REF_EXT'],[236.22,38.1,0],[136,133,90],notes='Fit shunt 1-2 for ground reference; 2-3 for external reference')
add('R1','100R 0.1%','R',RFP,['IN_P','IN_P_F'],[86.36,78.74,0],[116.5,116.8,0],notes='Thin film, <=25 ppm/C; matched input series resistors')
add('R2','100R 0.1%','R',RFP,['IN_N','IN_N_F'],[86.36,88.9,0],[116.5,121.2,0],notes='Thin film, <=25 ppm/C; matched input series resistors')
add('R3','10k 0.1%','R',RFP,['GAIN10','REF'],[152.4,139.7,90],[129.5,115,0],notes='Thin film, <=25 ppm/C; gain lower resistor')
add('R4','90.9k 0.1%','R',RFP,['OUT_RAW','GAIN10'],[152.4,119.38,90],[129.5,111.5,0],notes='Thin film, <=25 ppm/C; gain upper resistor')
add('R5','1k 0.1%','R',RFP,['GAIN101','REF'],[195.58,139.7,90],[134,128,0],notes='Thin film, <=25 ppm/C; gain lower resistor')
add('R6','100k 0.1%','R',RFP,['OUT_RAW','GAIN101'],[195.58,119.38,90],[134,124.5,0],notes='Thin film, <=25 ppm/C; gain upper resistor')
add('R7','100k','R',RFP,['BW','GND'],[172.72,43.18,90],[118,112,0],notes='Bandwidth default pull-down, 1%')
add('R8','100R','R',RFP,['OUT_RAW','OUT'],[203.2,76.2,0],[140,125,0],notes='Output isolation; 1%; sense feedback before this resistor')
add('R9','1M (DNP)','R',RFP,['IN_P_F','REF'],[88.9,134.62,90],[110.5,130,0],True,'Optional input bias return to REF; fit only as application requires')
add('R10','1M (DNP)','R',RFP,['IN_N_F','REF'],[116.84,134.62,90],[115,130,0],True,'Optional input bias return to REF; fit only as application requires')
add('C1','10uF / 16V','C',CFP,['VS','GND'],[63.5,43.18,0],[111,111,0],notes='X7R or X5R; bulk bypass; check capacitance under DC bias')
add('C2','100nF / 16V','C',CFP,['VS','GND'],[96.52,43.18,0],[126,123,0],notes='X7R; local U1 bypass')
add('C3','10nF (DNP)','C',CFP,['IN_P_F','IN_N_F'],[33.02,134.62,0],[111,119.5,90],True,'C0G, 25 V; optional differential input filter')
add('C4','1nF (DNP)','C',CFP,['IN_P_F','GND'],[50.8,134.62,0],[110,124.8,0],True,'C0G, 25 V, 1%; match C5 if fitted')
add('C5','1nF (DNP)','C',CFP,['IN_N_F','GND'],[68.58,134.62,0],[115,125.5,0],True,'C0G, 25 V, 1%; match C4 if fitted')
add('C6','10nF (DNP)','C',CFP,['OUT','GND'],[218.44,91.44,0],[140,128.5,0],True,'Optional output low-pass capacitor after R8')
for i,(net,xy) in enumerate([('VS',(107,110)),('GND',(107,130)),('IN_P_F',(120,125.5)),('IN_N_F',(120,130)),('OUT_RAW',(134,108)),('FB',(132.5,119)),('REF',(128,132))],1):
    add('TP'+str(i),net,'TP',TP,[net],[27.94+(i-1)*22.86,162.56,0],[*xy,0],notes='Exposed 1.5 mm probe pad')
for i,xy in enumerate([(103.5,103.5),(146.5,103.5),(103.5,136.5),(146.5,136.5)],1):
    add('H'+str(i),'M3 NPTH','Hole',HOLE,[],[218.44+(i-1)*15.24,160.02,0],[*xy,0],notes='3.2 mm non-plated mounting hole')

def esc(x): return str(x).replace('\\','\\\\').replace('"','\\"').replace('\n','\\n')
def effects(size=1.27,extra=''): return f'(effects (font (size {size} {size})) {extra})'
def prop(k,v,x=0,y=0,hide=False,size=1.27,angle=0):
    return f'(property "{esc(k)}" "{esc(v)}" (at {x} {y} {angle}) {effects(size,"(hide yes)" if hide else "")})'
def pin(n,name,x,y,angle,typ='passive',length=2.54):
    return dict(n=str(n),name=name,x=x,y=y,a=angle,typ=typ,length=length)
pins={
 'R':[pin(1,'~',-5.08,0,0),pin(2,'~',5.08,0,180)],
 'C':[pin(1,'~',0,5.08,270,length=4.318),pin(2,'~',0,-5.08,90,length=4.318)],
 'AD8237':[pin(1,'BW',-15.24,-10.16,0,'input',5.08),pin(2,'+IN',-15.24,5.08,0,'input',5.08),pin(3,'-IN',-15.24,-5.08,0,'input',5.08),pin(4,'-VS',0,-20.32,90,'power_in',7.62),pin(5,'+VS',0,20.32,270,'power_in',7.62),pin(6,'REF',15.24,-7.62,180,'input',5.08),pin(7,'FB',15.24,0,180,'input',5.08),pin(8,'OUT',15.24,7.62,180,'output',5.08)],
 'TP':[pin(1,'~',0,0,90,length=2.54)],'Hole':[],
 'Flag':[pin(1,'pwr',0,0,90,'power_out',0)]}
for n in [2,3]: pins['Conn'+str(n)]=[pin(i,str(i),-7.62,(n-1)*2.54/2-(i-1)*2.54,0) for i in range(1,n+1)]
pins['Gain']=sum(([pin(2*i+1,'FB',-10.16,5.08-5.08*i,0),pin(2*i+2,['1','10.09','101'][i],10.16,5.08-5.08*i,180)] for i in range(3)),[])
def line(points,width=.254): return '(polyline (pts '+' '.join(f'(xy {x} {y})' for x,y in points)+f') (stroke (width {width}) (type default)) (fill (type none)))'
def rect(x1,y1,x2,y2):return f'(rectangle (start {x1} {y1}) (end {x2} {y2}) (stroke (width 0.254) (type default)) (fill (type background)))'
def symdef(kind,fullname):
    g=[]
    if kind=='R':g=[rect(-2.54,1.016,2.54,-1.016)]
    if kind=='C':g=[line([(-2.54,.762),(2.54,.762)]),line([(-2.54,-.762),(2.54,-.762)])]
    if kind=='AD8237':g=[rect(-10.16,12.7,10.16,-12.7)]
    if kind.startswith('Conn'):g=[rect(-5.08,5.08,0,-5.08)]
    if kind=='Gain':g=[rect(-7.62,8.89,7.62,-8.89)]
    if kind in ['TP','Hole']:g=[f'(circle (center 0 {3.3 if kind=="TP" else 0}) (radius {0.76 if kind=="TP" else 2.54}) (stroke (width 0.254) (type default)) (fill (type none)))']
    if kind=='Flag':g=[line([(0,0),(0,2.54),(-1.27,2.54),(0,3.81),(1.27,2.54),(0,2.54)])]
    pstrings=[]
    for p in pins[kind]:pstrings.append(f'(pin {p["typ"]} line (at {p["x"]} {p["y"]} {p["a"]}) (length {p["length"]}) (name "{p["name"]}" {effects(1.016)}) (number "{p["n"]}" {effects(1.016)}))')
    hide_names=kind in ['R','C','TP','Hole','Flag']
    return f'(symbol "{fullname}" (pin_names (offset 0.508) {"(hide yes)" if hide_names else ""}) (exclude_from_sim no) (in_bom yes) (on_board yes) '+prop('Reference',{'R':'R','C':'C','AD8237':'U','Hole':'H','TP':'TP','Flag':'#FLG'}.get(kind,'J'),0,5.08)+prop('Value',kind,0,-5.08)+prop('Footprint','',hide=True)+prop('Datasheet','',hide=True)+f'(symbol "{kind}_0_1" '+''.join(g)+f') (symbol "{kind}_1_1" '+''.join(pstrings)+'))'

def generate():
    # Rotate vertical resistors so pin 1 is at the top of each divider.
    for p in parts:
        if p['kind']=='R' and p['sch'][2]==90:p['sch'][2]=270
    for d in ['AD8237DevBoard.pretty','docs','manufacturing','tmp']:(ROOT/d).mkdir(exist_ok=True)
    kinds=list(pins)
    symbols={k:symdef(k,'AD8237DevBoard:'+k) for k in kinds}
    (ROOT/(NAME+'.kicad_sym')).write_text('(kicad_symbol_lib (version 20241209) (generator "kicad_symbol_editor") '+'\n'.join(symdef(k,k) for k in kinds)+')',encoding='utf-8')
    (ROOT/'sym-lib-table').write_text('(sym_lib_table (version 7) (lib (name "AD8237DevBoard") (type "KiCad") (uri "${KIPRJMOD}/AD8237DevBoard.kicad_sym") (options "") (descr "Project symbols; AD8237 datasheet Rev. 0")))\n')
    (ROOT/'fp-lib-table').write_text('(fp_lib_table (version 7) (lib (name "AD8237DevBoard") (type "KiCad") (uri "${KIPRJMOD}/AD8237DevBoard.pretty") (options "") (descr "Project-local copies of official KiCad footprints")))\n')
    for p in parts:
        lib,f=p['source_fp'].split(':')
        shutil.copyfile(KICAD/'footprints'/(lib+'.pretty')/(f+'.kicad_mod'),ROOT/'AD8237DevBoard.pretty'/(f+'.kicad_mod'))
    out=[f'(kicad_sch (version 20250114) (generator "eeschema") (uuid "{SHEET}") (paper "A4") (title_block (title "AD8237 Sensor Development Board") (date "2026-09-20") (rev "A") (company "Micro-DMM") (comment 1 "3.3 V nominal | 5 V compatible | 50 x 40 mm | Prototype")) (lib_symbols '+''.join(symbols.values())+')']
    def wire(a,b):out.append(f'(wire (pts (xy {a[0]:g} {a[1]:g}) (xy {b[0]:g} {b[1]:g})) (stroke (width 0) (type default)) (uuid "{uuid.uuid4()}"))')
    def label(net,xy,ang=0):out.append(f'(label "{net}" (at {xy[0]:g} {xy[1]:g} {ang}) {effects(1.016,"(justify left bottom)")} (uuid "{uuid.uuid4()}"))')
    def text(t,x,y,size=1.27):out.append(f'(text "{esc(t)}" (at {x} {y} 0) {effects(size,"(justify left top)")} (uuid "{uuid.uuid4()}"))')
    import math
    def coord(x,y,p,a):
        c=round(math.cos(math.radians(a)));s=round(math.sin(math.radians(a)))
        return x+p[0]*c-p[1]*s,y-p[0]*s-p[1]*c
    for p in parts:
        x,y,a=p['sch'];kind=p['kind']
        if kind=='AD8237':rx,ry=x+12.7,y-19.05;vx,vy=x+12.7,y-16.51
        elif kind=='Gain':rx,ry=x,y-12.7;vx,vy=x,y+12.7
        elif kind in ['C'] or (kind=='R' and a in [90,270]):rx,ry=x+8.89,y-1.905;vx,vy=x+8.89,y+.635
        elif kind=='TP':rx,ry=x,y-7.62;vx,vy=x,y+5.08
        elif kind.startswith('Conn'):rx,ry=x,y-10.16;vx,vy=x,y-7.62
        else:rx,ry=x,y-6.35;vx,vy=x,y-3.81
        out.append(f'(symbol (lib_id "AD8237DevBoard:{kind}") (at {x} {y} {a}) (unit 1) (in_bom yes) (on_board yes) (dnp {"yes" if p["dnp"] else "no"}) (uuid "{p["uuid"]}") '+prop('Reference',p['ref'],rx,ry,size=1.016,angle=90 if a in [90,270] else 0)+prop('Value',p['value'],vx,vy,hide=kind=='TP',size=1.016,angle=90 if a in [90,270] else 0)+prop('Footprint',p['fp'],x,y,True)+prop('Datasheet','https://www.analog.com/media/en/technical-documentation/data-sheets/ad8237.pdf' if kind=='AD8237' else '',x,y,True)+prop('Assembly',p['notes'],x,y,True)+''.join(f'(pin "{pin_["n"]}" (uuid "{uid(p["ref"]+"pin"+pin_["n"])}"))' for pin_ in pins[kind])+f'(instances (project "{NAME}" (path "/{SHEET}" (reference "{p["ref"]}") (unit 1)))))')
        for pp in pins[kind]:
            xy=coord(x,y,(pp['x'],pp['y']),a)
            # Every pin has an explicit wired net label. Main input and gain branches are joined below.
            theta=math.radians(pp['a']+a)
            end=(round(xy[0]-6.35*math.cos(theta),5),round(xy[1]+6.35*math.sin(theta),5))
            wire(xy,end);label(p['nets'][pp['n']],end,0)
    # Actual wires in the central signal path and gain divider branches.
    for y in [78.74,88.9]:wire((97.79,y),(118.11,y))
    for x in [152.4,195.58]:wire((x,130.81),(x,128.27))
    for i,(net,x) in enumerate([('VS',76.2),('GND',109.22)]):
        y=27.94;ref='#FLG0'+str(i+1)
        out.append(f'(symbol (lib_id "AD8237DevBoard:Flag") (at {x} {y} 0) (unit 1) (in_bom no) (on_board no) (dnp no) (uuid "{uid(ref)}") '+prop('Reference',ref,x,y,True)+prop('Value','PWR_FLAG',x,y-5.08,True)+f'(pin "1" (uuid "{uid(ref+"pin")}")) (instances (project "{NAME}" (path "/{SHEET}" (reference "{ref}") (unit 1)))))')
        wire((x,y),(x,y+2.54));label(net,(x,y+2.54),0)
    text('AD8237 | SENSOR DEVELOPMENT',20.32,15.24,2.286)
    text('POWER: regulated 3.3 V nominal; 5 V supported (1.8-5.5 V operating)',20.32,20.32)
    text('BANDWIDTH',139.7,20.32);text('REFERENCE',223.52,20.32)
    text('JP2: 1-2 = LOW (default)\n2-3 = HIGH; gain >= 10 only',152.4,57.15,1.016)
    text('JP3: 1-2 = GND (default)\n2-3 = external reference at J3.3',213.36,55.88,1.016)
    text('DIFFERENTIAL INPUT',20.32,63.5);text('OUTPUT',238.76,63.5)
    text('OPTIONAL INPUT FILTER / BIAS RETURN',20.32,110.49)
    text('GAIN NETWORKS (0.1% resistors)',144.78,102.87)
    text('JP1: one shunt required\n1-2: 1 V/V\n3-4: 10.09 V/V (default)\n5-6: 101 V/V',228.6,139.7,1.016)
    text('TEST POINTS',20.32,151.13)
    text('VOUT_RAW = VREF + G x (VIN+ - VIN-)\nExternal REF must drive BOTH divider returns. Use a low-impedance source.\nR9/R10 and C3-C6 are NOT FITTED by default. Provide a sensor DC bias return.\nUse LOW bandwidth for unity gain. Change jumpers with power off.\nInput, REF and output voltages must remain within supply rails for normal use.',20.32,176.53,1.016)
    out.append('(embedded_fonts no))')
    (ROOT/(NAME+'.kicad_sch')).write_text('\n'.join(out),encoding='utf-8')
    project=json.loads((KICAD/'template/kicad.kicad_pro').read_text())
    project['meta']['filename']=NAME+'.kicad_pro'
    project['board']['design_settings']['rules']={'min_clearance':0.2,'min_track_width':0.2,'min_via_diameter':0.6,'min_through_hole_diameter':0.3,'min_hole_clearance':0.25,'min_hole_to_hole':0.25,'min_copper_edge_clearance':0.3,'min_silk_clearance':0.1,'min_text_height':0.8,'min_text_thickness':0.12}
    project['net_settings']={'meta':{'version':4},'classes':[{'name':'Default','clearance':0.2,'track_width':0.25,'via_diameter':0.6,'via_drill':0.3,'microvia_diameter':0.3,'microvia_drill':0.1,'diff_pair_width':0.2,'diff_pair_gap':0.25,'diff_pair_via_gap':0.25,'pcb_color':'rgba(0, 0, 0, 0.000)','schematic_color':'rgba(0, 0, 0, 0.000)','wire_width':6,'bus_width':12,'line_style':0}]}
    (ROOT/(NAME+'.kicad_pro')).write_text(json.dumps(project,indent=2)+'\n')
    (ROOT/'scripts/components.json').write_text(json.dumps(parts,indent=2)+'\n')
    with (ROOT/'manufacturing/BOM.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.writer(f);w.writerow(['Reference','Value','Footprint','Fit','Specification / assembly note'])
        for p in parts:w.writerow([p['ref'],p['value'],p['fp'],'PCB feature' if p['kind'] in ['TP','Hole'] else ('DNP' if p['dnp'] else 'YES'),p['notes']])
        w.writerow(['SH1-SH3','2.54 mm jumper shunt','Accessory','YES','Three shunts: JP1 3-4, JP2 1-2, JP3 1-2'])
    print('Created schematic, libraries, project and BOM:',len(parts),'components')

if __name__=='__main__':generate()
