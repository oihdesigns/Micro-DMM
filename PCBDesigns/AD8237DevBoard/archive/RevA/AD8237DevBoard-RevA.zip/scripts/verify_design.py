"""Independent checks against the KiCad-exported XML netlist and rule reports."""
from pathlib import Path
import xml.etree.ElementTree as ET
import json, math

ROOT=Path(__file__).resolve().parents[1]
tree=ET.parse(ROOT/'docs/netlist.xml')
pin_net={}
for net in tree.findall('./nets/net'):
    for n in net.findall('node'):pin_net[n.get('ref'),n.get('pin')]=net.get('name').lstrip('/')
expected={
    'U1':['BW','IN_P_F','IN_N_F','GND','VS','REF','FB','OUT_RAW'],
    'J1':['VS','GND'],'J2':['IN_P','IN_N','GND'],'J3':['OUT','GND','REF_EXT'],
    'JP1':['FB','OUT_RAW','FB','GAIN10','FB','GAIN101'],
    'JP2':['GND','BW','VS'],'JP3':['GND','REF','REF_EXT'],
    'R1':['IN_P','IN_P_F'],'R2':['IN_N','IN_N_F'],
    'R3':['GAIN10','REF'],'R4':['OUT_RAW','GAIN10'],
    'R5':['GAIN101','REF'],'R6':['OUT_RAW','GAIN101'],
    'R7':['BW','GND'],'R8':['OUT_RAW','OUT'],
    'R9':['IN_P_F','REF'],'R10':['IN_N_F','REF'],
    'C1':['VS','GND'],'C2':['VS','GND'],
    'C3':['IN_P_F','IN_N_F'],'C4':['IN_P_F','GND'],
    'C5':['IN_N_F','GND'],'C6':['OUT','GND']}
for ref,nets in expected.items():
    for i,net in enumerate(nets,1):assert pin_net[ref,str(i)]==net,(ref,i,pin_net[ref,str(i)],net)
components={c.get('ref'):c for c in tree.findall('./components/comp')}
def resistor(ref):
    s=components[ref].findtext('value').split()[0].replace('R','')
    scale=1
    if s[-1] in 'kM':scale={'k':1e3,'M':1e6}[s[-1]];s=s[:-1]
    return float(s)*scale
gains=[1,1+resistor('R4')/resistor('R3'),1+resistor('R6')/resistor('R5')]
assert all(math.isclose(a,b,abs_tol=1e-10) for a,b in zip(gains,[1,10.09,101]))
dc=[]
for vs in [3.3,5]:
    for g in gains:
        ref=vs/2;vd=.01;out=ref+g*vd
        assert .1 < out < vs-.1
        # Negative input-pair differential equals the selected FB-REF voltage.
        fb=ref+(out-ref)/g
        assert math.isclose(fb-ref,vd,abs_tol=1e-12)
        dc.append({'supply_V':vs,'gain':g,'reference_V':ref,'differential_input_V':vd,'ideal_raw_output_V':round(out,6)})
erc=json.loads((ROOT/'docs/ERC.json').read_text())
drc=json.loads((ROOT/'docs/DRC.json').read_text())
ne=sum(len(s['violations']) for s in erc['sheets'])
assert ne==0 and not drc['violations'] and not drc['unconnected_items'] and not drc['schematic_parity']
assert not json.loads((ROOT/'AD8237DevBoard.kicad_pro').read_text())['board']['design_settings'].get('drc_exclusions',[])
result={'status':'PASS','basis':'AD8237 Rev. 0 pinout and closed-loop DC equation; KiCad exported netlist',
    'pin_connections_checked':sum(len(v) for v in expected.values()),'erc_violations':ne,
    'drc_violations':len(drc['violations']),'unconnected_items':len(drc['unconnected_items']),
    'schematic_parity_issues':len(drc['schematic_parity']),'custom_drc_exclusions':0,
    'ideal_dc_cases':dc,'gain_network_parallel_load_ohm':1/(1/(resistor('R3')+resistor('R4'))+1/(resistor('R5')+resistor('R6'))),
    'limitations':'No physical prototype measurements or device-level transient/noise simulation. DC values assume an ideal amplifier, nominal resistors, ideal reference and no external output load.'}
(ROOT/'docs/design-verification.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS: pin mapping, connector mapping, reference returns, gain networks, six ideal DC operating points, ERC and DRC/parity.')
