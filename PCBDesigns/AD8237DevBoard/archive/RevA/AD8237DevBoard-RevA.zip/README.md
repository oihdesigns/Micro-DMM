# AD8237 Sensor Development Board - Rev A

An editable KiCad 10 development board for 3.3 V sensors, also operable from a regulated 5 V supply. Built against the supplied **AD8237 datasheet, Rev. 0 (2012)**, particularly pages 8 and 20-24, and the RM-8 package drawing on page 27.

**Status:** routed prototype design; KiCad ERC, DRC and schematic/PCB parity checked. This board has not been fabricated or measured. DC gain calculations are ideal circuit checks, not a device-level stability/noise simulation.

## Open the design

Open `AD8237DevBoard.kicad_pro` in KiCad 10. The schematic, routed PCB, symbols and footprints are all in this folder. Symbols and footprints use project-local libraries; optional 3D models use KiCad's installed standard model library.

- `docs/AD8237DevBoard-schematic.pdf`: schematic for review.
- `docs/PCB-top.png`: assembled-board render (optional components omitted; shunts not modeled).
- `manufacturing/AD8237DevBoard-RevA-Gerbers.zip`: fabrication package.
- `manufacturing/BOM.csv`: component requirements and population notes.
- `manufacturing/placement.csv`: KiCad SMD placement coordinates, with DNP parts excluded. Check the assembler's rotation/origin convention before use.
- `docs/ERC.json`, `docs/DRC.json`, `docs/design-verification.json`: verification records.

## Board and circuit

| Item | Specification |
|---|---|
| Board | 50 x 40 mm, two copper layers, 1.6 mm FR-4, nominal 1 oz copper |
| Mounting | Four 3.2 mm non-plated holes, centers 3.5 mm from each adjacent edge; 43 x 33 mm spacing |
| Amplifier | AD8237ARMZ, MSOP-8, standard KiCad 3 x 3 mm / 0.65 mm footprint |
| Supply | Regulated 3.3 V nominal; 5 V uses the same connector with no changes; device operating range 1.8-5.5 V |
| Gains | 1, 10.09, 101 V/V, selected by ONE jumper |
| Bandwidth | Low by default; high available for gains of 10 or more |
| Reference | Ground or external voltage selected with a jumper |
| Passives | 0805; gain and input resistors 0.1% thin film, <=25 ppm/degree C |
| Connectors | Through-hole 2.54 mm pin headers |
| Copper rules | 0.20 mm minimum track/clearance; 0.60/0.30 mm via diameter/drill; ground pours on both layers |
| Test points | Supply, ground, filtered IN+/IN-, raw output, feedback and reference |

There is no regulator, voltage translation, reverse-polarity protection or onboard reference generator. Apply a regulated supply directly. A 5 V supply can produce an output above a 3.3 V ADC's input range; use the 3.3 V supply or constrain the output appropriately when connecting a 3.3 V ADC. This is a low-voltage sensor board, not a high-voltage measurement input.

## Connections and jumpers

Pin 1 is the square pad. Connector numbering is also visible in the PCB editor and schematic.

| Connector | Pin 1 | Pin 2 | Pin 3 |
|---|---|---|---|
| J1 POWER | VS (3.3 V or 5 V) | GND | - |
| J2 SENSOR | IN+ | IN- | GND |
| J3 OUTPUT | OUT (after 100 ohm R8) | GND | External REF input |
| JP2 BW | GND / LOW | BW | VS / HIGH |
| JP3 REFERENCE | GND | REF | External REF |

| Jumper | Setting | Action |
|---|---|---|
| JP1 gain, top row | Pins 1-2 | Gain = 1 |
| JP1 gain, middle row | **Pins 3-4, default** | Gain = 10.09 (silkscreen abbreviated to 10) |
| JP1 gain, bottom row | Pins 5-6 | Gain = 101 |
| JP2 bandwidth | **Pins 1-2, default** | Low bandwidth; valid for all gains |
| JP2 bandwidth | Pins 2-3 | High bandwidth; use only at gain 10.09 or 101 |
| JP3 reference | **Pins 1-2, default** | REF grounded |
| JP3 reference | Pins 2-3 | REF driven from J3 pin 3 |

Fit exactly one shunt per jumper header. JP1 must have a shunt for closed-loop operation; JP3 must have a shunt for a defined reference. Power off before changing settings. With JP2 empty, R7 pulls BW low. Do not use the high-bandwidth setting at unity gain.

Supply three ordinary 2.54 mm shunts with the board. Shunts are accessories in the BOM; they are not PCB footprints or placement-file entries.

## Reference and signal range

At the raw output (TP5), the nominal relationship is:

`VOUT_RAW = VREF + G * (VIN+ - VIN-)`

R4/R3 set `1 + 90.9k/10k = 10.09`; R6/R5 set `1 + 100k/1k = 101`. Both divider networks remain connected between OUT_RAW and REF. JP1 selects only the high-impedance feedback sense point, so shunt contact resistance is not part of either gain resistor. Both divider returns and U1 REF are connected to the same selected reference.

The two dividers together present approximately 50.475 kilohms between output and reference. Use a low-impedance reference source capable of sourcing and sinking that current (about 33 microamps at a 1.65 V output-reference difference). An unbuffered resistor divider will alter gain and output centering; it is not an ideal reference for this board.

For a bipolar differential signal on a 3.3 V supply, drive external REF with **1.65 V**, then select JP3 pins 2-3. At gain 10.09, a +/-150 mV differential signal ideally produces about 0.1365-3.1635 V at TP5. At gain 101, +/-15 mV produces about 0.135-3.165 V. Keep each physical input within 0-3.3 V as well. With REF grounded, negative differential signals clip near ground.

Allow output headroom rather than expecting exact rail voltage. Datasheet swing depends on load and temperature. Prefer an output load of at least 100 kilohms; a 10 kilohm load in parallel with the gain networks is below the datasheet's recommended effective 10 kilohm load. R8 creates an additional DC divider with the external load (approximately 0.10% attenuation into 100 kilohms). TP5 is before R8, and feedback senses before R8.

The device's quoted 0.005% gain error excludes external resistor error. With independent 0.1% gain resistors, worst-case ratio-related gain error is about +/-0.181% at G=10.09 and +/-0.199% at G=101, before amplifier, reference, thermal and output-loading errors. Calibrate the assembled circuit if absolute accuracy matters.

## Optional parts

**Do not populate C3-C6 or R9-R10 for the default assembly.** The BOM, schematic and PCB mark these DNP.

- R1 and R2 are fitted 100 ohm input series resistors. They provide configurable input impedance and modest current limiting; they do not make the inputs tolerant of arbitrary overvoltage. For overload applications, recalculate protection from the datasheet's 5 mA input-current limit and the expected voltage.
- C3 (10 nF) adds differential filtering. C4/C5 (1 nF each) add matched common-mode filtering. Use matched 1% C0G parts for C4/C5 if fitted. With the default 100 ohm resistors and all three fitted, nominal differential cutoff is about 75.8 kHz and common-mode cutoff about 1.59 MHz, ignoring sensor source impedance. Increase both series resistors equally for lower cutoff, accounting for input noise and bias errors.
- R9/R10 (1 Mohm) provide optional DC bias return paths to REF for floating or capacitively coupled sensors. A floating source needs a bias-current return path; decide which resistors to fit for that sensor. They load the source and their bias-current drops can matter for precision signals.
- C6 (10 nF) with fitted R8 (100 ohms) provides an optional output pole around 159 kHz into a high-impedance load. It is **not** a strong 27 kHz chopping-ripple filter. Recalculate R8/C6 for the required signal bandwidth, ADC settling and loading; a switched-capacitor ADC may require buffering.

The AD8237 already includes RFI filtering. External filter footprints are provided for experiments. Do not infer a measured noise, CMRR, bandwidth or stability specification from the existence of those footprints.

## First power-up

1. Inspect U1 pin-1 orientation and soldering; check that VS is not shorted to ground. Fit the three default shunts.
2. With power off, connect J2 IN+ and IN- to the same known in-range voltage, such as 1.65 V. Ground-reference operation places the zero-differential output at the lower rail, so use external 1.65 V REF for a useful zero-offset test.
3. Apply a current-limited 3.3 V supply to J1 (for example a 5 mA limit for initial bench testing). Connect grounds between source, board and measuring instrument.
4. Verify VS at TP1, ground at TP2 and selected REF at TP7. At zero differential input with 1.65 V REF, TP5 should be close to 1.65 V.
5. At gain 10.09, apply +10 mV differential input while preserving a valid common-mode voltage. Expect about 1.7509 V at TP5; reversing the differential polarity gives about 1.5491 V. Compare J3 OUT with TP5 to check output loading.
6. Power off, select each other gain, and repeat with a suitably small input. Check settling and oscillation with the actual sensor/cable/ADC and both permitted bandwidth modes before relying on measurements.

The amplifier itself typically draws 115 microamps. Reference-network current, the BW pull-down in high mode, output load and optional components add to total supply consumption.

## Fabrication and assembly

Use the zipped Gerbers plus separate plated/non-plated Excellon drill files for a 2-layer, 1.6 mm board. The archive includes front/back copper, solder mask, silkscreen and the closed board outline. Separate paste layers are provided in `manufacturing/stencil`; default DNP pads are removed from the supplied stencil data. Do not send paste layers as copper layers.

Generic passive specifications are provided rather than unverified supplier stock numbers. U1's orderable part is AD8237ARMZ (or the same die/package in a tape-and-reel suffix). Verify exact purchasing parts, capacitor DC-bias performance and the assembler's placement rotations when preparing an assembly order. Mounting holes and test pads are PCB features, not purchased parts.

The PCB is fully routed and has filled ground planes. Final KiCad 10 checks report zero ERC violations, zero DRC violations, zero unconnected items and zero schematic-parity issues; no custom exclusions were added. The board should still be treated as an untested prototype until bench evaluation.

## Rebuilding

The design can be edited normally in KiCad. `scripts/design.py` and `scripts/build_pcb.py` are reproducible source generators and **overwrite** the schematic/PCB when run; do not run them over later manual edits. `scripts/export.ps1` reruns validation and exports, and stops on failed checks. KiCad 10 is expected at its default Windows installation path.

Source: Analog Devices, [AD8237 datasheet](https://www.analog.com/media/en/technical-documentation/data-sheets/ad8237.pdf), Rev. 0; supplied locally at `C:/Users/Nick/Documents/Datasheets/ad8237.pdf`.
